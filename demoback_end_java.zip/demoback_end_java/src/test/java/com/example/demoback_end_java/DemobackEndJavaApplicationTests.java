package com.example.demoback_end_java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemobackEndJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
