package com.example.demoback_end_java;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemobackEndJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemobackEndJavaApplication.class, args);
	}

}
